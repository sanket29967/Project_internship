from flask import Flask, request, jsonify, render_template
import re
import random
import string

app = Flask(__name__)

# Password strength checker function
def check_strength(password):
    strength = 0
    feedback = []

    if len(password) >= 8:
        strength += 1
    else:
        feedback.append("Use at least 8 characters")

    if re.search(r"[A-Z]", password):
        strength += 1
    else:
        feedback.append("Add uppercase letters")

    if re.search(r"\d", password):
        strength += 1
    else:
        feedback.append("Add numbers")

    if re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        strength += 1
    else:
        feedback.append("Add special characters")

    if strength <= 2:
        return "Weak", "\n".join(feedback)
    elif strength == 3:
        return "Medium", "\n".join(feedback)
    else:
        return "Strong", "Looks good!"

# Home route
@app.route("/")
def home():
    return render_template("index.html")

# Check password route
@app.route("/check", methods=["POST"])
def check():
    password = request.form["password"]
    strength, message = check_strength(password)
    return jsonify({"strength": strength, "message": message})

# Password generator route
@app.route("/generate", methods=["POST"])
def generate_password():
    length = int(request.form["length"])
    use_upper = request.form["upper"] == "true"
    use_numbers = request.form["numbers"] == "true"
    use_symbols = request.form["symbols"] == "true"

    chars = string.ascii_lowercase
    if use_upper:
        chars += string.ascii_uppercase
    if use_numbers:
        chars += string.digits
    if use_symbols:
        chars += string.punctuation

    password = ''.join(random.choice(chars) for _ in range(length))
    return jsonify({"password": password})

if __name__ == "__main__":
    app.run(debug=True)


 